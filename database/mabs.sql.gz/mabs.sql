-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2023 at 03:21 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mabs`
--

-- --------------------------------------------------------

--
-- Table structure for table `boroweditem`
--

CREATE TABLE `boroweditem` (
  `borrowed_id` int(11) NOT NULL,
  `student_name` varchar(30) NOT NULL,
  `id_number` varchar(10) NOT NULL,
  `cell_number` varchar(15) NOT NULL,
  `course` varchar(12) NOT NULL,
  `year_level` varchar(10) NOT NULL,
  `section` varchar(20) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `approvedBy` varchar(30) NOT NULL,
  `borrow_date` date NOT NULL,
  `due_date` date NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `good_item` int(11) NOT NULL,
  `bad_item` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `boroweditem`
--

INSERT INTO `boroweditem` (`borrowed_id`, `student_name`, `id_number`, `cell_number`, `course`, `year_level`, `section`, `purpose`, `approvedBy`, `borrow_date`, `due_date`, `item_name`, `good_item`, `bad_item`) VALUES
(6, 'Jeffrey', '2020-1387', '09456424506', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'CSS NCII', 'John Gabriel Espanueva', '2023-12-20', '2023-12-21', 'Duck Tape', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `history_id` int(11) NOT NULL,
  `borrowed_id` int(11) NOT NULL,
  `student_name` varchar(30) NOT NULL,
  `id_number` varchar(10) NOT NULL,
  `cell_number` varchar(15) NOT NULL,
  `course` varchar(30) NOT NULL,
  `year_level` varchar(10) NOT NULL,
  `section` varchar(30) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `approvedBy` varchar(30) NOT NULL,
  `borrow_date` date NOT NULL,
  `due_date` date NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `good_item` int(11) NOT NULL,
  `bad_item` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`history_id`, `borrowed_id`, `student_name`, `id_number`, `cell_number`, `course`, `year_level`, `section`, `purpose`, `approvedBy`, `borrow_date`, `due_date`, `item_name`, `good_item`, `bad_item`) VALUES
(1, 4, 'Jeffrey Tuason', '2020-1387', '09456424506', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'CSS NCII', 'John Gabriel Espanueva', '2023-12-19', '2023-12-19', 'Duck Tape', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `item_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `good_item` int(11) NOT NULL,
  `bad_item` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `location` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`item_id`, `name`, `good_item`, `bad_item`, `category`, `location`) VALUES
(2, 'Dust Pan', 3, 0, 'Furniture', 'Stock Room'),
(4, 'Screw Driver', 3, 1, 'Hand Tools', 'Maintainance'),
(5, 'Duck Tape', 10, 0, 'Electric Hardware', 'Maintainance'),
(6, 'Broom', 5, 0, 'Furniture', 'Stock Room');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `boroweditem`
--
ALTER TABLE `boroweditem`
  ADD PRIMARY KEY (`borrowed_id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`history_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`item_id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `boroweditem`
--
ALTER TABLE `boroweditem`
  MODIFY `borrowed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
